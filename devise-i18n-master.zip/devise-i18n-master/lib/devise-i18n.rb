require 'devise-i18n/railtie' if defined?(Rails)
